	<div class="navigation">
		<input type="checkbox" class="navigation__checkbox" id="navi-toggle">
		<label for="navi-toggle" class="navigation__button">
			<span class="navigation__icon">&nbsp;</span>
		</label>

		<div class="navigation__background">&nbsp;</div>

		<nav class="navigation__nav">
			<ul class="navigation__list">
				<li class="navigation__item"><a href="trang-chu.php" class="navigation__link"><span>01</span>Trang Chủ</a></li>
				<li class="navigation__item"><a href="wifi-gia-dinh"
						class="navigation__link"><span>02</span>Internet + Truyền Hình</a></li>
				<li class="navigation__item"><a href="tra-sau-viettel"
						class="navigation__link"><span>03</span>Dịch Vụ Di Động</a></li>
				<li class="navigation__item"><a href="404" class="navigation__link"><span>04</span>Mua Sim</a></li>
<!-- 				<li class="navigation__item"><a href="404" class="navigation__link"><span>05</span>Mua Điện Thoại</a>
				</li> -->
				<li class="navigation__item"><a href="404" class="navigation__link"><span>05</span>Tin Tức</a>
				</li>
			</ul>
		</nav>
	</div>